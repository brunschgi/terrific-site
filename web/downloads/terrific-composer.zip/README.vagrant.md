# Using Terrific Composer with Vagrant

## Get Vagrant & VirtualBox, if you don't have already

From http://vagrantup.com/ & https://www.virtualbox.org/wiki/Downloads

## Get the code and go to the terrific-composer directory

See https://github.com/brunschgi/terrific-composer/blob/master/README.md for the details

## startup vagrant

    vagrant up

## watch site

go to http://192.168.11.12/app_dev.php and be happy (hopefully, maybe reload it twice, if it doesn't work the first time)


