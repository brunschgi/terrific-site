(function ($) {

    "use strict";

    /**
     * Hero module implementation.
     *
     * @author Terrific Composer
     * @namespace Tc.Module
     * @class Hero
     * @extends Tc.Module
     */
    Tc.Module.Hero = Tc.Module.extend({

        /**
         * Initializes the Hero module.
         *
         * @method init
         * @return {void}
         * @constructor
         * @param {jQuery} $ctx the jquery context
         * @param {Sandbox} sandbox the sandbox to get the resources from
         * @param {Number} id the unique module id
         */
        init:function ($ctx, sandbox, id) {
            // call base constructor
            this._super($ctx, sandbox, id);
        },

        /**
         * Hook function to do all of your module stuff.
         *
         * @method on
         * @param {Function} callback function
         * @return void
         */
        on:function (callback) {
            var $ctx = this.$ctx,
                self = this;

            // extract the name and provide the default greeting
            $('.message', $ctx).val('Hi, I am ' + $('pre', $ctx).data('name'));

            // bind the submit event on the form
            $('form', $ctx).bind('submit', function () {
                var name = $('pre', $ctx).data('name'),
                    message = $('.message', $ctx).val();

                // write the current message in the bubble and notify the others
                self.fire('message', { name:name, message:message}, function () {
                    $('.bubble', $ctx).text(message);
                });

                return false;
            });

            callback();
        },

        /**
         * Hook function to trigger your events.
         *
         * @method after
         * @return void
         */
        after:function () {
            var $ctx = this.$ctx;

            // trigger the first submit to write the default message in the bubble
            $('form', $ctx).trigger('submit');
        },


        /**
         * Handles the incoming messages from the other superheroes
         */
        onMessage:function (data) {
            var $ctx = this.$ctx;

            data = data || {};

            if (data.name && data.message) {
                $('.bubble', $ctx).text(data.name + ' said: ' + data.message);
            }
        }

    });
})(Tc.$);

(function ($) {

    "use strict";

    /**
     * Intro module implementation.
     *
     * @author Terrific Composer
     * @namespace Tc.Module
     * @class Intro
     * @extends Tc.Module
     */
    Tc.Module.Intro = Tc.Module.extend({

        /**
         * Initializes the Intro module.
         *
         * @method init
         * @return {void}
         * @constructor
         * @param {jQuery} $ctx the jquery context
         * @param {Sandbox} sandbox the sandbox to get the resources from
         * @param {Number} id the unique module id
         */
        init:function ($ctx, sandbox, id) {
            // call base constructor
            this._super($ctx, sandbox, id);
        },

        /**
         * Hook function to do all of your module stuff.
         *
         * @method on
         * @param {Function} callback function
         * @return void
         */
        on:function (callback) {
            callback();
        },

        /**
         * Hook function to trigger your events.
         *
         * @method after
         * @return void
         */
        after:function () {

        }
    });
})(Tc.$);

(function ($) {

    "use strict";

    /**
     * Teaser module implementation.
     *
     * @author Terrific Composer
     * @namespace Tc.Module
     * @class Teaser
     * @extends Tc.Module
     */
    Tc.Module.Teaser = Tc.Module.extend({

        /**
         * Initializes the Teaser module.
         *
         * @method init
         * @return {void}
         * @constructor
         * @param {jQuery} $ctx the jquery context
         * @param {Sandbox} sandbox the sandbox to get the resources from
         * @param {Number} id the unique module id
         */
        init:function ($ctx, sandbox, id) {
            // call base constructor
            this._super($ctx, sandbox, id);
        },

        /**
         * Hook function to do all of your module stuff.
         *
         * @method on
         * @param {Function} callback function
         * @return void
         */
        on:function (callback) {
            callback();
        },

        /**
         * Hook function to trigger your events.
         *
         * @method after
         * @return void
         */
        after:function () {

        }
    });
})(Tc.$);

(function ($) {

    "use strict";

    /**
     * Stealth Skin implementation for module Hero.
     *
     * @author Terrific Composer
     * @namespace Tc.Module.Hero
     * @class Stealth
     * @extends Tc.Module
     * @constructor
     */
    Tc.Module.Hero.Stealth = function (parent) {
        /**
         * override the appropriate methods from the decorated module (ie. this.get = function()).
         * the former/original method may be called via parent.<method>()
         */
         this.on = function (callback) {
            var self = this,
                $ctx = this.$ctx;

            // create mode chooser markup
            $ctx.append($('<div class="mode"><h3>Stealth Mode</h3><a href="#" title="activate stealth mode" class="on">on</a><a href="#" title="deactivate stealth mode" class="off">off</a></div>'));

            // binding the stealth mode on / off events
            $('.on', $ctx).bind('click', function () {
                self.activateStealthMode();
                return false;
            });

            $('.off', $ctx).bind('click', function () {
                self.deactivateStealthMode();
                return false;
            });

            // calling parent method
            parent.on(callback);
        };

        this.activateStealthMode = function () {
            var self = this,
                $hero = $('pre', this.$ctx);

            $hero.hide(100).show(100).hide(100).show(100).animate({ opacity:0.2 }, 500, function () {
                $hero.show(200).hide(200).show(200).hide(200);
            });
        };

        this.deactivateStealthMode = function () {
            var self = this,
                $hero = $('pre', this.$ctx);

            $hero.show(200).hide(200).show(200).animate({ opacity:1 }, 500, function () {
                $hero.hide(100).show(100).hide(100).show(100);
            });
        };
    };
})(Tc.$);
