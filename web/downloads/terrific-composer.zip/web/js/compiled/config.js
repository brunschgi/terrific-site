require.config({
    shim:{
        'dom':{
            exports:'$',
            deps:['zepto'] // switch to the DOM-lib of your choice
        }
    },
    paths:{
        zepto:'/js/compiled/zepto.min',
        terrificjs:'/js/compiled/terrific-2.0.1.min',

        // terrific modules
        tc_mod_hero:'/bundles/terrificmodulehero/js/Tc.Module.Hero'
    }
});