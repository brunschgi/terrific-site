(function($){Tc.Module.ComposerTool=Tc.Module.extend({init:function($ctx,sandbox,modId){this._super($ctx,sandbox,modId);},onBinding:function(){var $ctx=this.$ctx,that=this,$template=$('.template',$ctx),$skins=$(".skins",$ctx),$mod=$($('body .mod').get(0));$template.chosen().on('change',function(){var url=$(this).val(),skins=$skins.val();if(skins){if($.isArray(skins)){skins=skins.join(',');}
window.location=url+'/'+skins;}
else{window.location=url;}});$('.skins',$ctx).chosen().on('change',function(){var skins=$(this).val(),url=$template.val();if(skins){if($.isArray(skins)){skins=skins.join(',');}
window.location=url+'/'+skins;}
else{window.location=url;}});$('.dimension').on('keyup',function(e,instantly){var $this=$(this),val=$this.val();instantly=instantly||false;if(!instantly){$mod.stop(true,true).animate({width:val},500,function(){$.cookie('composermodulewidth',val);});}
else{$mod.css({'width':val});}}).val($.cookie('composermodulewidth')||'auto').trigger('keyup',true);}});})(Tc.$);